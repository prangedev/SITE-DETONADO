# Detonados Games

Loja/portal de detonados de jogos — Next.js 14 (App Router) + TypeScript + Tailwind CSS.
Catálogo estilo loja, verificador de compatibilidade de hardware, sistema de
usuários com XP/níveis/conquistas, ranking global, multilíngue (7 idiomas) e
notificações (in-app, e-mail e web push).

## Stack

- **Next.js 14** (App Router, Server Components + Server Actions/Route Handlers)
- **TypeScript** + **Tailwind CSS**
- **Prisma** + **SQLite** (compatível com Turso/libsql em produção)
- **NextAuth.js** (Credentials — e-mail/senha, JWT)
- **next-intl** (pt-BR, en, es, fr, de, ja, ko)
- **Resend** (e-mail), **web-push** (push no navegador)
- APIs públicas da **Steam** + **SteamSpy** + **ProtonDB** para o catálogo

## Decisões de arquitetura (leia antes de rodar)

Para chegar a um projeto que realmente builda e roda no Vercel, alguns pontos
do pedido original foram resolvidos de forma pragmática — documentado aqui
com total transparência:

1. **Steam scraping sem Puppeteer.** Puppeteer é pesado e frágil em funções
   serverless da Vercel (precisa de `@sparticuz/chromium`, aumenta cold start
   e quebra a cada atualização do Chrome). Em vez disso, `src/lib/steam.ts`
   usa as APIs públicas em JSON da Steam (`store.steampowered.com/api/appdetails`)
   e da SteamSpy (lista de populares) — mesma fonte de dados, sem o overhead.
2. **"Tempo real" das notificações in-app é polling (a cada ~20s)**, não
   WebSocket. Funções serverless não seguram conexões persistentes de forma
   confiável. Para tempo real de verdade, plugue Pusher/Ably/Supabase Realtime
   no ponto único de criação de notificação (`src/lib/notifications.ts`).
3. **Comparação de CPU/GPU usa uma tabela de "tiers" curada manualmente**
   (`src/lib/hardware-tiers.json`), não um banco de benchmarks real (PassMark/
   UserBenchmark exigem acesso pago). O resultado é uma boa estimativa, não
   uma medição exata — o app deixa isso explícito para o usuário.
4. **SQLite por padrão, mas o filesystem do Vercel é efêmero.** Para produção,
   troque `DATABASE_URL` para um banco Turso (libsql, mesma sintaxe SQL) ou
   migre o `provider` do `prisma/schema.prisma` para `postgresql` + Vercel
   Postgres. Instruções abaixo.
5. **Cron jobs**: o plano Hobby da Vercel limita a frequência/quantidade de
   cron jobs. Se você estiver nesse plano, use um serviço externo como
   cron-job.org apontando para as mesmas rotas (`/api/cron/...`) com o header
   `Authorization: Bearer <CRON_SECRET>`.

## Instalação local

```bash
npx create-next-app@latest detonados-games   # (já feito neste projeto — pule esse passo)
cd detonados-games
npm install

cp .env.example .env
# edite .env: gere NEXTAUTH_SECRET e CRON_SECRET com `openssl rand -base64 32`

npm run db:push      # cria o banco SQLite local a partir do schema
npm run db:seed       # popula conquistas + 2 jogos de exemplo

npm run dev           # http://localhost:3000
```

Para popular o catálogo com dados reais da Steam:

```bash
npm run sync:steam    # busca os 10 jogos mais populares, specs e tier ProtonDB
```

Isso cria os jogos com status `DRAFT` e já os distribui automaticamente em
turnos (manhã/tarde/noite, 2 por turno). Rode o publicador manualmente para
testar sem esperar o cron:

```bash
curl http://localhost:3000/api/cron/publish-scheduled-games
```

### Notificações por e-mail e push (opcional em dev)

Sem `RESEND_API_KEY` ou chaves VAPID configuradas, os envios de e-mail/push
viram no-ops silenciosos — o app funciona normalmente, só não envia. Para
ativar:

```bash
npm run generate:vapid   # gera NEXT_PUBLIC_VAPID_PUBLIC_KEY e VAPID_PRIVATE_KEY
```

E crie uma conta gratuita em [resend.com](https://resend.com) para o
`RESEND_API_KEY`.

## Variáveis de ambiente

Veja `.env.example` para a lista completa e comentada. Resumo:

| Variável | Obrigatória | Descrição |
|---|---|---|
| `DATABASE_URL` | sim | Conexão do banco (SQLite local ou Turso/Postgres em produção) |
| `NEXTAUTH_URL` | sim | URL pública do app |
| `NEXTAUTH_SECRET` | sim | Segredo de sessão (`openssl rand -base64 32`) |
| `RESEND_API_KEY` | não | Ativa e-mails de notificação |
| `EMAIL_FROM` | não | Remetente dos e-mails |
| `NEXT_PUBLIC_VAPID_PUBLIC_KEY` / `VAPID_PRIVATE_KEY` | não | Ativa web push |
| `CRON_SECRET` | recomendado | Protege as rotas `/api/cron/*` |

## Deploy no Vercel

1. Suba o projeto para um repositório Git (GitHub/GitLab/Bitbucket).
2. Em [vercel.com/new](https://vercel.com/new), importe o repositório.
3. Configure as variáveis de ambiente do `.env.example` no painel do projeto
   (Settings → Environment Variables).
4. **Banco de dados em produção** — escolha uma opção:
   - **Turso (recomendado, mais próximo do pedido original)**: crie um banco
     em [turso.tech](https://turso.tech), pegue a `DATABASE_URL` (formato
     `libsql://...`) e o auth token. Instale o driver adapter:
     ```bash
     npm install @libsql/client @prisma/adapter-libsql
     ```
     e ajuste `src/lib/db.ts` para usar o adapter do libsql (veja a doc do
     Prisma "Driver Adapters" para o snippet exato da sua versão).
   - **Vercel Postgres**: crie o banco no painel da Vercel, troque
     `provider = "sqlite"` para `provider = "postgresql"` em
     `prisma/schema.prisma` e use a `DATABASE_URL` fornecida.
5. Rode as migrações contra o banco de produção antes do primeiro deploy:
   ```bash
   npx prisma db push
   npx tsx prisma/seed.ts
   ```
6. Deploy. O `vercel.json` já registra os cron jobs de publicação (3x ao dia,
   um por turno) e de sincronização com a Steam (1x ao dia). Ajuste os
   horários no `vercel.json` se quiser turnos diferentes.

## Estrutura de pastas

```
src/
  app/
    [locale]/         # todas as páginas (home, jogo, login, perfil, ranking...)
    api/               # rotas de API (auth, registro, hardware-check, cron...)
  components/          # Header, cards, formulários, UI primitives
  i18n/                # roteamento e configuração do next-intl
  messages/            # traduções (pt-BR, en, es, fr, de, ja, ko)
  lib/                 # Prisma client, auth, XP, conquistas, Steam, hardware...
  scripts/             # script de sincronização com a Steam
prisma/
  schema.prisma
  seed.ts
```

## Limitações conhecidas / próximos passos

- O parser de requisitos da Steam (`parseHtmlRequirements`) é uma heurística
  baseada em regex sobre HTML solto — funciona bem para a maioria dos jogos,
  mas formatos muito fora do padrão podem não ser capturados perfeitamente.
- A fila de notificações no cron de publicação (`publishDueGames`) itera
  usuário a usuário; em escala grande, migre para uma fila real
  (Inngest, QStash, etc.).
- Não há upload de avatar nem OAuth (Google/GitHub) configurados — a base
  do NextAuth já está pronta para adicionar providers facilmente.
