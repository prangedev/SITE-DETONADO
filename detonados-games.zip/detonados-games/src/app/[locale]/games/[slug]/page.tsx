import Image from "next/image";
import { notFound } from "next/navigation";
import { getTranslations } from "next-intl/server";
import { db } from "@/lib/db";
import { safeJsonParse } from "@/lib/utils";
import { getCurrentUserId } from "@/lib/current-user";
import { grantAchievement } from "@/lib/achievements";
import { Badge } from "@/components/ui/badge";
import { HardwareCheckForm } from "@/components/hardware-check-form";
import type { ParsedRequirements } from "@/lib/hardware-compat";
import { PLATFORM_LABELS, type PlatformType } from "@/lib/constants";

const PROTON_TIER_COLORS: Record<string, string> = {
  native: "text-mint",
  platinum: "text-ink",
  gold: "text-warn",
  silver: "text-ink-muted",
  bronze: "text-brand",
  borked: "text-danger",
};

export default async function GameDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const t = await getTranslations("game");

  const game = await db.game.findFirst({ where: { slug, releaseStatus: "PUBLISHED" } });
  if (!game) notFound();

  const userId = await getCurrentUserId();
  if (userId) {
    await grantAchievement(userId, "first-game-viewed");
  }

  const platforms = safeJsonParse<PlatformType[]>(game.platforms, []);
  const genres = safeJsonParse<string[]>(game.genres, []);
  const minReq = safeJsonParse<ParsedRequirements | null>(game.minRequirements, null);
  const recReq = safeJsonParse<ParsedRequirements | null>(game.recRequirements, null);

  return (
    <div className="space-y-6">
      <div className="relative aspect-[21/9] w-full overflow-hidden rounded-xl border border-base-border bg-base-raised">
        {game.headerImage && (
          <Image src={game.headerImage} alt={game.title} fill className="object-cover" priority />
        )}
      </div>

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink">{game.title}</h1>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {platforms.map((p) => (
              <Badge key={p}>{PLATFORM_LABELS[p]}</Badge>
            ))}
            {genres.map((g) => (
              <Badge key={g}>{g}</Badge>
            ))}
          </div>
        </div>
        {game.protonDbTier && (
          <div className="rounded-lg border border-base-border bg-base-surface px-3 py-2 text-right">
            <p className="font-mono text-[10px] uppercase tracking-wider text-ink-faint">
              {t("protonCompat")}
            </p>
            <p className={`font-display text-sm font-bold uppercase ${PROTON_TIER_COLORS[game.protonDbTier] ?? "text-ink"}`}>
              {game.protonDbTier}
            </p>
          </div>
        )}
      </div>

      {game.shortDescription && <p className="text-sm text-ink-muted">{game.shortDescription}</p>}

      <div className="grid gap-4 md:grid-cols-2">
        <RequirementsTable title={t("minRequirements")} req={minReq} t={t} />
        <RequirementsTable title={t("recRequirements")} req={recReq} t={t} />
      </div>

      <HardwareCheckForm gameId={game.id} />

      <div>
        <h2 className="mb-2 font-display text-lg font-bold text-ink">{t("walkthrough")}</h2>
        <div className="whitespace-pre-wrap rounded-xl border border-base-border bg-base-surface p-4 text-sm leading-relaxed text-ink-muted">
          {game.detonado || t("noWalkthrough")}
        </div>
      </div>
    </div>
  );
}

function RequirementsTable({
  title,
  req,
  t,
}: {
  title: string;
  req: ParsedRequirements | null;
  t: Awaited<ReturnType<typeof getTranslations>>;
}) {
  if (!req) return null;
  const rows: [string, string | number | undefined][] = [
    [t("os"), req.os],
    [t("processor"), req.cpu],
    [t("memory"), req.ramGb ? `${req.ramGb} GB` : undefined],
    [t("graphics"), req.gpu],
    [t("storage"), req.storageGb ? `${req.storageGb} GB` : undefined],
  ];

  return (
    <div className="rounded-xl border border-base-border bg-base-surface p-4">
      <h3 className="mb-3 font-mono text-xs uppercase tracking-wider text-ink-faint">{title}</h3>
      <dl className="space-y-2 font-mono text-xs">
        {rows
          .filter(([, value]) => value)
          .map(([label, value]) => (
            <div key={label} className="flex justify-between gap-3 border-b border-base-border/50 pb-1.5">
              <dt className="text-ink-faint">&gt; {label}</dt>
              <dd className="text-right text-ink">{value}</dd>
            </div>
          ))}
      </dl>
    </div>
  );
}
