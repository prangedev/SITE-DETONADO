import { db } from "./db";
import { computeLevelProgress } from "./xp";
import { createNotification } from "./notifications";

/**
 * Adiciona XP a um usuário e cria notificação de "subiu de nível" quando
 * aplicável. Retorna o progresso de nível atualizado.
 */
export async function addXp(userId: string, amount: number) {
  const user = await db.user.findUniqueOrThrow({ where: { id: userId } });
  const before = computeLevelProgress(user.xp);
  const newXp = user.xp + amount;
  const after = computeLevelProgress(newXp);

  await db.user.update({
    where: { id: userId },
    data: { xp: newXp, level: after.level },
  });

  if (after.level > before.level) {
    await createNotification({
      userId,
      type: "LEVEL_UP",
      title: `Você alcançou o nível ${after.level}!`,
      message: `Continue jogando e explorando detonados para subir ainda mais.`,
    });

    if (after.level >= 5) await grantAchievement(userId, "level-5");
    if (after.level >= 10) await grantAchievement(userId, "level-10");
    if (after.level >= 20) await grantAchievement(userId, "level-20");
  }

  return after;
}

/**
 * Concede uma conquista ao usuário (idempotente — não duplica) e credita
 * o XP correspondente à raridade dela.
 */
export async function grantAchievement(userId: string, achievementKey: string) {
  const achievement = await db.achievement.findUnique({ where: { key: achievementKey } });
  if (!achievement) return null;

  const already = await db.userAchievement.findUnique({
    where: { userId_achievementId: { userId, achievementId: achievement.id } },
  });
  if (already) return null;

  await db.userAchievement.create({
    data: { userId, achievementId: achievement.id },
  });

  await addXp(userId, achievement.xpReward);

  await createNotification({
    userId,
    type: "ACHIEVEMENT",
    title: `Conquista desbloqueada: ${achievement.name}`,
    message: `${achievement.description} (+${achievement.xpReward} XP)`,
  });

  return achievement;
}
