"use client";

import { useTranslations } from "next-intl";
import { useSession, signOut } from "next-auth/react";
import { Gamepad2, Cpu, Trophy, User } from "lucide-react";
import { Link } from "@/i18n/navigation";
import { SearchBar } from "@/components/search-bar";
import { LanguageSwitcher } from "@/components/language-switcher";
import { NotificationBell } from "@/components/notification-bell";
import { Button } from "@/components/ui/button";

export function Header() {
  const t = useTranslations("nav");
  const { data: session, status } = useSession();

  return (
    <header className="sticky top-0 z-40 border-b border-base-border bg-base/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-3">
        <div className="flex items-center justify-between gap-3">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand shadow-glow">
              <Gamepad2 className="h-[18px] w-[18px] text-white" />
            </div>
            <span className="font-display text-base font-bold tracking-tight text-ink">
              Detonados<span className="text-brand">Games</span>
            </span>
          </Link>

          <div className="hidden flex-1 justify-center sm:flex">
            <SearchBar />
          </div>

          <div className="flex items-center gap-2">
            <Link
              href="/leaderboard"
              className="hidden h-9 items-center gap-1.5 rounded-full border border-base-border px-3 text-xs text-ink-muted hover:border-ink-faint md:flex"
            >
              <Trophy className="h-3.5 w-3.5" /> {t("leaderboard")}
            </Link>
            <Link
              href="/hardware-check"
              className="hidden h-9 items-center gap-1.5 rounded-full border border-base-border px-3 text-xs text-ink-muted hover:border-ink-faint md:flex"
            >
              <Cpu className="h-3.5 w-3.5" /> {t("hardwareCheck")}
            </Link>

            <LanguageSwitcher />
            <NotificationBell />

            {status === "authenticated" ? (
              <div className="flex items-center gap-1.5">
                <Link
                  href="/profile"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-base-border bg-base-surface text-ink hover:border-ink-faint"
                  aria-label={t("profile")}
                >
                  <User className="h-4 w-4" />
                </Link>
                <Button variant="ghost" size="sm" onClick={() => signOut()}>
                  {t("logout")}
                </Button>
              </div>
            ) : (
              <Link href="/login">
                <Button size="sm">{t("login")}</Button>
              </Link>
            )}
          </div>
        </div>

        <div className="sm:hidden">
          <SearchBar />
        </div>
      </div>
    </header>
  );
}
