import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const ACHIEVEMENTS = [
  {
    key: "first-login",
    name: "Primeiro Acesso",
    description: "Criou sua conta em Detonados Games.",
    rarity: "COMUM",
    xpReward: 10,
  },
  {
    key: "first-game-viewed",
    name: "Explorador",
    description: "Visitou a página de um jogo pela primeira vez.",
    rarity: "COMUM",
    xpReward: 10,
  },
  {
    key: "hardware-check-done",
    name: "Diagnóstico Completo",
    description: "Testou a compatibilidade do seu PC pela primeira vez.",
    rarity: "COMUM",
    xpReward: 15,
  },
  {
    key: "level-5",
    name: "Veterano",
    description: "Alcançou o nível 5.",
    rarity: "RARA",
    xpReward: 50,
  },
  {
    key: "level-10",
    name: "Mestre dos Detonados",
    description: "Alcançou o nível 10.",
    rarity: "EPICA",
    xpReward: 150,
  },
  {
    key: "level-20",
    name: "Lenda Viva",
    description: "Alcançou o nível 20.",
    rarity: "LENDARIA",
    xpReward: 500,
  },
];

// Jogos de exemplo para a loja não ficar vazia antes do primeiro sync com a
// Steam (rode `npm run sync:steam` para popular com dados reais).
const SAMPLE_GAMES = [
  {
    slug: "hollow-knight-367520",
    steamAppId: 367520,
    title: "Hollow Knight",
    coverImage: "https://cdn.akamai.steamstatic.com/steam/apps/367520/header.jpg",
    headerImage: "https://cdn.akamai.steamstatic.com/steam/apps/367520/header.jpg",
    shortDescription:
      "Um exigente jogo de ação e aventura 2D ambientado em um vasto reino de insetos e heróis.",
    platforms: JSON.stringify(["PC", "SWITCH", "PS4", "XBOX_ONE"]),
    genres: JSON.stringify(["Ação", "Aventura", "Indie"]),
    minRequirements: JSON.stringify({ os: "Windows 7", cpu: "Intel Core i3", gpu: "GeForce GTX 260", ramGb: 4, storageGb: 9 }),
    recRequirements: JSON.stringify({ os: "Windows 10", cpu: "Intel Core i5", gpu: "GeForce GTX 460", ramGb: 8, storageGb: 9 }),
    protonDbTier: "platinum",
    detonado: "Guia em construção: dicas de progressão, mapa e chefes principais em breve.",
  },
  {
    slug: "stardew-valley-413150",
    steamAppId: 413150,
    title: "Stardew Valley",
    coverImage: "https://cdn.akamai.steamstatic.com/steam/apps/413150/header.jpg",
    headerImage: "https://cdn.akamai.steamstatic.com/steam/apps/413150/header.jpg",
    shortDescription: "Você herdou a velha fazenda do seu avô. Comece uma nova vida no campo!",
    platforms: JSON.stringify(["PC", "MOBILE", "SWITCH", "PS4", "XBOX_ONE"]),
    genres: JSON.stringify(["Simulação", "RPG", "Indie"]),
    minRequirements: JSON.stringify({ os: "Windows Vista", cpu: "2 Ghz", gpu: "256mb placa de vídeo", ramGb: 2, storageGb: 1 }),
    recRequirements: JSON.stringify({ os: "Windows 10", cpu: "Intel Core i5", gpu: "GeForce GTX 660", ramGb: 4, storageGb: 1 }),
    protonDbTier: "platinum",
    detonado: "Guia em construção: dicas de cultivo, relacionamentos e minas em breve.",
  },
];

async function main() {
  for (const achievement of ACHIEVEMENTS) {
    await db.achievement.upsert({
      where: { key: achievement.key },
      update: achievement,
      create: achievement,
    });
  }

  for (const game of SAMPLE_GAMES) {
    await db.game.upsert({
      where: { slug: game.slug },
      update: game,
      create: { ...game, releaseStatus: "PUBLISHED" },
    });
  }

  console.log(`Seed concluído: ${ACHIEVEMENTS.length} conquistas, ${SAMPLE_GAMES.length} jogos de exemplo.`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
