import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        base: {
          DEFAULT: "#100E17",
          surface: "#1A1725",
          raised: "#241F32",
          border: "#332C46",
        },
        ink: {
          DEFAULT: "#F2EEF7",
          muted: "#9A93A8",
          faint: "#6A6379",
        },
        brand: {
          DEFAULT: "#FF3D81",
          soft: "#FF6FA3",
          dim: "#4D1030",
        },
        mint: {
          DEFAULT: "#35E7C6",
          dim: "#0E4A40",
        },
        warn: {
          DEFAULT: "#FFB84D",
          dim: "#4A3410",
        },
        danger: {
          DEFAULT: "#FF5C5C",
          dim: "#4A1414",
        },
        rarity: {
          comum: "#8A93A6",
          rara: "#4D9CFF",
          epica: "#B562FF",
          lendaria: "#FFB84D",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        scanlines:
          "repeating-linear-gradient(0deg, rgba(255,255,255,0.025) 0px, rgba(255,255,255,0.025) 1px, transparent 1px, transparent 3px)",
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(255,61,129,0.25), 0 0 24px rgba(255,61,129,0.15)",
        "glow-mint": "0 0 0 1px rgba(53,231,198,0.25), 0 0 24px rgba(53,231,198,0.15)",
      },
    },
  },
  plugins: [],
};

export default config;
